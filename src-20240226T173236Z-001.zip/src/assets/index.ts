import sliderOne from "@/assets/slider/sliderOne.png";
import sliderTwo from "@/assets/slider/sliderTwo.png";
import sliderThree from "@/assets/slider/sliderThree.png";
import sliderFour from "@/assets/slider/sliderFour.png";

export { sliderOne, sliderTwo, sliderThree, sliderFour };
