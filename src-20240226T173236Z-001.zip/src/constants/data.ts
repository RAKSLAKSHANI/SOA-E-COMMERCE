export const navigation = [
  { _id: 910, title: "Home", href: "/" },
  { _id: 911, title: "Phones", href: "/phones" },
  { _id: 912, title: "Phone Cases", href: "/phonecases" },
  { _id: 913, title: "Watches", href: "/watches" },
  { _id: 914, title: "Accessories", href: "/accessories" },
];
