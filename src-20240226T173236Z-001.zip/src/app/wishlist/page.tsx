import Container from "@/components/Container";
import Title from "@/components/Title";
import React from "react";

const page = () => {
  return (
    <Container>
      <Title title="Your Wishlist" />
    </Container>
  );
};

export default page;
